from typing import Tuple
import re
from CSP import Assignment, Problem, UnaryConstraint, BinaryConstraint

#TODO (Optional): Import any builtin library or define any helper function you want to use

# This is a class to define for cryptarithmetic puzzles as CSPs
class CryptArithmeticProblem(Problem):
    LHS: Tuple[str, str]
    RHS: str

    # Convert an assignment into a string (so that is can be printed).
    def format_assignment(self, assignment: Assignment) -> str:
        LHS0, LHS1 = self.LHS
        RHS = self.RHS
        letters = set(LHS0 + LHS1 + RHS)
        formula = f"{LHS0} + {LHS1} = {RHS}"
        postfix = []
        valid_values = list(range(10))
        for letter in letters:
            value = assignment.get(letter)
            if value is None: continue
            if value not in valid_values:
                postfix.append(f"{letter}={value}")
            else:
                formula = formula.replace(letter, str(value))
        if postfix:
            formula = formula + " (" + ", ".join(postfix) +  ")" 
        return formula

    @staticmethod
    def from_text(text: str) -> 'CryptArithmeticProblem':
        # Given a text in the format "LHS0 + LHS1 = RHS", the following regex
        # matches and extracts LHS0, LHS1 & RHS
        # For example, it would parse "SEND + MORE = MONEY" and extract the
        # terms such that LHS0 = "SEND", LHS1 = "MORE" and RHS = "MONEY"
        pattern = r"\s*([a-zA-Z]+)\s*\+\s*([a-zA-Z]+)\s*=\s*([a-zA-Z]+)\s*"
        match = re.match(pattern, text)
        if not match: raise Exception("Failed to parse:" + text)
        LHS0, LHS1, RHS = [match.group(i+1).upper() for i in range(3)]

        problem = CryptArithmeticProblem()
        problem.LHS = (LHS0, LHS1)
        problem.RHS = RHS

        #TODO Edit and complete the rest of this function
        # problem.variables:    should contain a list of variables where each variable is string (the variable name)
        # problem.domains:      should be dictionary that maps each variable (str) to its domain (set of values)
        #                       For the letters, the domain can only contain integers in the range [0,9].
        # problem.constaints:   should contain a list of constraint (either unary or binary constraints).
        chars=set(LHS0+LHS1+RHS)
        problem.variables = list(chars)
        problem.domains = {char:{0,1,2,3,4,5,6,7,8,9}for char in chars}
        # Add auxiliary variables for carries
        max_length = max(len(LHS0), len(LHS1), len(RHS))
        carry_vars = [f"C{i}" for i in range(max_length)]  # Carry variables
        problem.variables.extend(carry_vars)
        for carry in carry_vars:
            problem.domains[carry] = {0, 1}  # Carry is always 0 or 1
            
        problem.constraints = []
        # 1. Add unary constraints for leading digits (cannot be 0)
        for word in [LHS0, LHS1, RHS]:
            leading_letter = word[0]
            problem.constraints.append(
                UnaryConstraint(leading_letter, lambda x: x != 0)
            )

        # 2. Add binary constraints for unique digits
        for i, letter1 in enumerate(chars):
            for letter2 in list(chars)[i + 1:]:
                problem.constraints.append(
                    BinaryConstraint((letter1, letter2), lambda x, y: x != y)
                )

        # 3. Add a global constraint for the mathematical equation
        # Define column-wise addition constraints
        LHS0 = LHS0.rjust(max_length, "0")[::-1]  # Pad only for processing
        LHS1 = LHS1.rjust(max_length, "0")[::-1]
        RHS = RHS[::-1]
        problem.domains['0'] = {0}
        problem.variables.extend('0')

        for i in range(max_length):
            letter1 = LHS0[i]
            letter2 = LHS1[i]
            result = RHS[i]
            carry_in = carry_vars[i - 1] if i > 0 else '0'
            carry_out = carry_vars[i] if not(len(LHS0)==len(LHS1) and len(LHS1)==len(RHS) and i==max_length) else '0'
            
            # Add domains for '0' if not already defined
            if '0' not in problem.domains:
                problem.domains['0'] = {0}
                
            # Add constraint to ensure column addition is valid
            def mega_constraint(mega1, mega2):
                x, y,carry_in = mega1  # Values of letter1 and letter2
                z,carry_out = mega2  # Values of result and carry_out
                return x + y +carry_in == z + 10*carry_out
            
            mega_variable1=(letter1,letter2,carry_in)
            # Define their domains
            problem.domains[mega_variable1] = {
                (x, y,z) for x in problem.domains[letter1] for y in problem.domains[letter2] for z in problem.domains[carry_in]
            }
            problem.variables.extend(mega_variable1)
            mega_variable2=(result,carry_out)
            # Define their domains
            problem.domains[mega_variable2] = {
                (x, y) for x in problem.domains[result] for y in problem.domains[carry_out]
            }
            problem.variables.extend(mega_variable2)
            problem.constraints.append(
                                        BinaryConstraint((mega_variable1, mega_variable2), mega_constraint))
            problem.constraints.append(
                                        BinaryConstraint((mega_variable1, letter1), lambda a,b: a[0]==b))
            problem.constraints.append(
                                        BinaryConstraint((mega_variable1, letter2), lambda a,b: a[1]==b))
            problem.constraints.append(
                                        BinaryConstraint((mega_variable2, result), lambda a,b: a[0]==b))
            if i>0:
                problem.constraints.append(
                                            BinaryConstraint((mega_variable1, carry_in), lambda a,b: a[2]==b))
            if not(len(LHS0)==len(LHS1) and len(LHS1)==len(RHS) and i==max_length):
                problem.constraints.append(
                                            BinaryConstraint((mega_variable2, carry_out), lambda a,b: a[1]==b))                

        return problem

    # Read a cryptarithmetic puzzle from a file
    @staticmethod
    def from_file(path: str) -> "CryptArithmeticProblem":
        with open(path, 'r') as f:
            return CryptArithmeticProblem.from_text(f.read())